import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/Layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Plus, Trash2, Send, Loader2, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { api, type AccountCode, type BudgetRequest as DBBudgetRequest, type Requester, type Approver } from '@/lib/apiService';
import { emailService, type EmailData } from '@/lib/emailService';
import { AccountCodesDebug } from '@/components/Debug/AccountCodesDebug';

interface MaterialItem {
  item: string;
  quantity: string;
}

interface BudgetRequestForm {
  requester: string;
  request_date: string;
  account_code: string;
  amount: string;
  note: string;
  material_list: MaterialItem[];
}

interface EmailPreviewData {
  approverName: string;
  approverEmail: string;
  ccEmails: string;
}

interface AddBudgetRequestDialogProps {
  onSuccess: () => void;
  editRequest?: DBBudgetRequest;
}

export function AddBudgetRequestDialog({ onSuccess, editRequest }: AddBudgetRequestDialogProps) {
  const { toast } = useToast();
  const today = new Date().toISOString().split('T')[0];
  
  const [formData, setFormData] = useState<BudgetRequestForm>({
    requester: editRequest?.requester || '',
    request_date: editRequest?.request_date || today,
    account_code: editRequest?.account_code || '',
    amount: editRequest?.amount?.toString() || '',
    note: editRequest?.note || '',
    material_list: editRequest?.material_list || [{ item: '', quantity: '' }]
  });

  const [accountCodes, setAccountCodes] = useState<AccountCode[]>([]);
  const [requesters, setRequesters] = useState<Requester[]>([]);
  const [approvers, setApprovers] = useState<Approver[]>([]);
  const [isLoadingApprovers, setIsLoadingApprovers] = useState(true);
  const [isLoadingRequesters, setIsLoadingRequesters] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isLoadingAccountCodes, setIsLoadingAccountCodes] = useState(true);
  const [emailPreviewData, setEmailPreviewData] = useState<EmailPreviewData>({
    approverName: '',
    approverEmail: '',
    ccEmails: ''
  });
  const [currentRequestData, setCurrentRequestData] = useState<BudgetRequestForm | null>(null);
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  const loadRequesters = async () => {
    try {
      setIsLoadingRequesters(true);
      console.log("🔄 Fetching requesters...");
      const data = await api.getRequesters();
      console.log("📊 Requesters data:", data);
      setRequesters(data || []);
      console.log("✅ Requesters loaded:", data?.length || 0, "items");
    } catch (error) {
      console.error("❌ Error fetching requesters:", error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถโหลดรายชื่อผู้ขอได้",
        variant: "destructive"
      });
    } finally {
      setIsLoadingRequesters(false);
    }
  };

  const loadApprovers = async () => {
    try {
      setIsLoadingApprovers(true);
      console.log("🔄 Fetching approvers from multiple sources...");
      
      // Load from both sources in parallel
      const [approversData, settingsData] = await Promise.all([
        api.getApprovers().catch(err => {
          console.warn("Failed to load approvers table:", err);
          return [];
        }),
        api.getSettings().catch(err => {
          console.warn("Failed to load settings:", err);
          return [];
        })
      ]);
      
      // Get approver from settings
      const settingsApprover = {
        approverName: settingsData?.find(s => s.key === "approver_name")?.value || "",
        approverEmail: settingsData?.find(s => s.key === "approver_email")?.value || ""
      };
      
      // Combine approvers
      const combinedApprovers = [...(approversData || [])];
      
      // Add settings approver if exists and not duplicate
      if (settingsApprover.approverName && settingsApprover.approverEmail) {
        const isDuplicate = combinedApprovers.some(a => a.email === settingsApprover.approverEmail);
        if (!isDuplicate) {
          combinedApprovers.unshift({
            id: "settings",
            name: settingsApprover.approverName,
            email: settingsApprover.approverEmail,
            department: "หน้าที่หลัก",
            position: "ผู้อนุมัติหลัก",
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          });
        }
      }
      
      console.log("📊 Combined approvers data:", combinedApprovers);
      setApprovers(combinedApprovers);
      console.log("✅ Approvers loaded:", combinedApprovers?.length || 0, "items");
    } catch (error) {
      console.error("❌ Error fetching approvers:", error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถโหลดรายชื่อผู้อนุมัติได้",
        variant: "destructive"
      });
    } finally {
      setIsLoadingApprovers(false);
    }
  };

  useEffect(() => {
    fetchAccountCodes();
    loadRequesters();
    loadApprovers();
  }, []);

  const fetchAccountCodes = async () => {
    try {
      setIsLoadingAccountCodes(true);
      console.log('🔄 Fetching account codes...');
      const data = await api.getAccountCodes();
      console.log('📊 Account codes data:', data);
      setAccountCodes(data || []);
      console.log('✅ Account codes loaded:', data?.length || 0, 'items');
    } catch (error) {
      console.error('❌ Error fetching account codes:', error);
      toast({
        title: "เกิดข้อผิดพลาด",
        description: "ไม่สามารถดึงข้อมูลรหัสบัญชีได้",
        variant: "destructive",
      });
    } finally {
      setIsLoadingAccountCodes(false);
    }
  };


  const generateRequestNo = async (): Promise<string> => {
    try {
      const data = await api.getBudgetRequests();

      let nextNo = 1;
      if (data && data.length > 0) {
        const lastRequestNo = data[0].request_no;
        // Updated pattern to match BR-YYYY-XXX format
        const match = lastRequestNo.match(/BR-(\d{4})-(\d+)/);
        if (match) {
          const year = match[1];
          const sequence = parseInt(match[2]);
          const currentYear = new Date().getFullYear().toString();
          
          // If it's a new year, reset sequence to 1
          if (year === currentYear) {
            nextNo = sequence + 1;
          } else {
            nextNo = 1;
          }
        }
      }

      const currentYear = new Date().getFullYear();
      return `BR-${currentYear}-${nextNo.toString().padStart(3, '0')}`;
    } catch (error) {
      console.error('Error generating request number:', error);
      // Fallback to current timestamp if database query fails
      const timestamp = Date.now();
      const currentYear = new Date().getFullYear();
      return `BR-${currentYear}-${timestamp.toString().slice(-3)}`;
    }
  };


  const handleInputChange = (field: keyof BudgetRequestForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };


  const handleMaterialChange = (index: number, field: keyof MaterialItem, value: string) => {
    setFormData(prev => ({
      ...prev,
      material_list: prev.material_list.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };


  const addMaterialItem = () => {
    setFormData(prev => ({
      ...prev,
      material_list: [...prev.material_list, { item: '', quantity: '' }]
    }));
  };


  const removeMaterialItem = (index: number) => {
    if (formData.material_list.length > 1) {
      setFormData(prev => ({
        ...prev,
        material_list: prev.material_list.filter((_, i) => i !== index)
      }));
    }
  };


  const handleBudgetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.requester || !formData.account_code || !formData.amount) {
      toast({
        title: "กรุณากรอกข้อมูลให้ครบถ้วน",
        description: "ชื่อผู้ขอ รหัสบัญชี และจำนวนเงินเป็นข้อมูลที่จำเป็น",
        variant: "destructive",
      });
      return;
    }

    const selectedAccount = accountCodes.find(ac => ac.code === formData.account_code);
    const materialList = formData.material_list.filter(item => 
      item.item.trim() !== '' || item.quantity.trim() !== ''
    );
    
    const requestData = {
      requester: formData.requester,
      request_date: formData.request_date,
      account_code: formData.account_code,
      account_name: selectedAccount?.name || '',
      amount: parseFloat(formData.amount),
      note: formData.note,
      material_list: materialList,
    };

    
    setCurrentRequestData(requestData);
    openEmailPreviewModal(requestData);
  };


  const openEmailPreviewModal = (requestData: BudgetRequestForm) => {
    setCurrentRequestData(requestData);
    setIsEmailModalOpen(true);
  };


  const generateEmailPreview = () => {
    if (!currentRequestData) return "กำลังโหลดข้อมูล...";

    const itemsTable = currentRequestData.material_list && currentRequestData.material_list.length > 0 
      ? `<table style="width: 100%; border-collapse: collapse; margin: 15px 0; font-family: sans-serif; font-size: 14px; border: 1px solid #dee2e6;">
           <thead>
             <tr style="background-color: #f8f9fa;">
               <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-weight: 600; color: #495057;">รายการ</th>
               <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left; font-weight: 600; color: #495057;">จำนวน</th>
             </tr>
           </thead>
           <tbody>
             ${currentRequestData.material_list.map((item: MaterialItem, index: number) => `
               <tr style="background-color: ${index % 2 === 0 ? '#ffffff' : '#f8f9fa'};">
                 <td style="border: 1px solid #dee2e6; padding: 12px; color: #495057;">${item.item || 'ไม่ระบุ'}</td>
                 <td style="border: 1px solid #dee2e6; padding: 12px; color: #495057;">${item.quantity || 'ไม่ระบุ'}</td>
               </tr>`).join('')}
           </tbody>
         </table>` 
      : `<div style="padding: 15px; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; color: #6c757d; text-align: center;">
           <p style="margin: 0; font-style: italic;">(ไม่มีรายการวัสดุที่ระบุ)</p>
         </div>`;

    const emailContent = `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333;">
        <p style="margin-bottom: 15px;"><strong>เรียน ผจศ. คุณ ${emailPreviewData.approverName || '(ชื่อผู้อนุมัติ)'}</strong></p>
        <p style="margin-bottom: 15px;">ด้วย คุณ <strong>${currentRequestData.requester}</strong> ได้ขอใช้งบประมาณ <strong>${currentRequestData.account_name}</strong></p>
        <p style="margin-bottom: 15px;">เป็นจำนวนเงิน <strong style="color: #007bff;">${currentRequestData.amount.toLocaleString('th-TH')} บาท</strong> เพื่อจัดหารายการตามตารางดังต่อไปนี้:</p>
        ${itemsTable}
        <p style="margin-top: 20px; margin-bottom: 15px;">จึงเรียนมาเพื่อโปรดพิจารณาอนุมัติ</p>
        ${currentRequestData.note ? `<p style="margin-top: 15px; padding: 10px; background-color: #fff3cd; border-left: 4px solid #ffc107;"><strong>หมายเหตุ:</strong> ${currentRequestData.note}</p>` : ''}
      </div>
    `;

    return emailContent;
  };


  const sendBudgetRequest = async () => {
    if (!currentRequestData) return;
    
    setIsSendingEmail(true);
    
    try {
      console.log('Starting budget request process...');
      console.log('Current request data:', currentRequestData);
      
      // Generate request number
      const requestNo = await generateRequestNo();
      console.log('Generated request number:', requestNo);
      
      // Prepare data for PostgreSQL
      const postgresData = {
        request_no: requestNo,
        requester: currentRequestData.requester,
        request_date: currentRequestData.request_date,
        account_code: currentRequestData.account_code,
        amount: currentRequestData.amount,
        note: currentRequestData.note || '',
        material_list: currentRequestData.material_list,
        status: 'pending',
        created_at: new Date().toISOString()
      };

      
      console.log('PostgreSQL data to insert:', postgresData);
      
      // Insert into PostgreSQL
              const insertData = await api.createBudgetRequest({
        request_no: postgresData.request_no,
        requester: postgresData.requester,
        request_date: postgresData.request_date,
        account_code: postgresData.account_code,
        amount: postgresData.amount,
        note: postgresData.note,
        material_list: postgresData.material_list
      });
      
      console.log('PostgreSQL insert successful:', insertData);
      
      // Send email
      const ccEmails = emailPreviewData.ccEmails
        .split(',')
        .map(email => email.trim())
        .filter(email => email && email.includes('@'));
      
      await sendEmailViaPostfix(
        currentRequestData,
        emailPreviewData.approverName,
        emailPreviewData.approverEmail,
        ccEmails,
        requestNo
      );
      
      toast({
        title: "สำเร็จ ✅",
        description: "บันทึกข้อมูลและส่งอีเมลเรียบร้อยแล้ว",
      });
      
      setIsEmailModalOpen(false);
      onSuccess();
      
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "ไม่สามารถดำเนินการได้";
      console.error('Error in sendBudgetRequest:', error);
      toast({
        title: "เกิดข้อผิดพลาด ❌",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsSendingEmail(false);
    }
  };


  const sendEmailViaPostfix = async (requestData: BudgetRequestForm, approverName: string, approverEmail: string, ccEmails: string[], requestId: string) => {
    console.log('Preparing email via Postfix + Dovecot:', {
      to: approverEmail,
      cc: ccEmails,
      requestId
    });
    
    const appBaseUrl = window.location.origin;
    const approveUrl = `${appBaseUrl}/approval?request_id=${requestId}&decision=APPROVE`;
    const rejectUrl = `${appBaseUrl}/approval?request_id=${requestId}&decision=REJECT`;

    const itemsTable = requestData.material_list.length > 0 
      ? `<table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
           <thead style="background-color: #f8f9fa;">
             <tr>
               <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left;">รายการ</th>
               <th style="border: 1px solid #dee2e6; padding: 12px; text-align: left;">จำนวน</th>
             </tr>
           </thead>
           <tbody>
             ${requestData.material_list.map((i: MaterialItem, index: number) => `
               <tr style="background-color: ${index % 2 === 0 ? '#ffffff' : '#f8f9fa'};">
                 <td style="border: 1px solid #dee2e6; padding: 12px;">${i.item}</td>
                 <td style="border: 1px solid #dee2e6; padding: 12px;">${i.quantity}</td>
               </tr>`).join('')}
           </tbody>
         </table>` 
      : '<p>(ไม่มีรายการวัสดุที่ระบุ)</p>';

    // Create HTML email body
    const htmlBody = `
      <!DOCTYPE html>
      <html lang="th">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>คำขออนุมัติใช้งบประมาณ</title>
        <style>
          body { font-family: 'Sarabun', Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
          .content { background: #f8f9fa; padding: 20px; border-radius: 0 0 8px 8px; }
          .info-row { display: flex; justify-content: space-between; margin-bottom: 10px; }
          .label { font-weight: bold; color: #495057; }
          .value { color: #212529; }
          .actions { margin-top: 30px; text-align: center; }
          .btn { display: inline-block; padding: 12px 24px; margin: 0 10px; text-decoration: none; border-radius: 6px; font-weight: bold; }
          .btn-approve { background-color: #28a745; color: white; }
          .btn-reject { background-color: #dc3545; color: white; }
          .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; text-align: center; color: #6c757d; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1 style="margin: 0; text-align: center;">📋 คำขออนุมัติใช้งบประมาณ</h1>
          </div>
          <div class="content">
            <div class="info-row">
              <span class="label">ผู้ขอ:</span>
              <span class="value">${requestData.requester}</span>
            </div>
            <div class="info-row">
              <span class="label">วันที่:</span>
              <span class="value">${new Date(requestData.request_date).toLocaleDateString('th-TH')}</span>
            </div>
            <div class="info-row">
              <span class="label">รหัสบัญชี:</span>
              <span class="value">${requestData.account_code}</span>
            </div>
            <div class="info-row">
              <span class="label">จำนวนเงิน:</span>
              <span class="value">฿${parseFloat(requestData.amount).toLocaleString('th-TH')}</span>
            </div>
            <div class="info-row">
              <span class="label">หมายเหตุ:</span>
              <span class="value">${requestData.note || '-'}</span>
            </div>
            
            <h3>รายการวัสดุ</h3>
            ${itemsTable}
            
            <div class="actions">
              <a href="${approveUrl}" class="btn btn-approve">✅ อนุมัติ</a>
              <a href="${rejectUrl}" class="btn btn-reject">❌ ไม่อนุมัติ</a>
            </div>
            
            <div class="footer">
              <p>อีเมลนี้ถูกส่งจากระบบ Stock Scribe Analyzer</p>
              <p>หากมีข้อสงสัย กรุณาติดต่อผู้ดูแลระบบ</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    // Create plain text version
    const textBody = `
คำขออนุมัติใช้งบประมาณ

ผู้ขอ: ${requestData.requester}
วันที่: ${new Date(requestData.request_date).toLocaleDateString('th-TH')}
รหัสบัญชี: ${requestData.account_code}
จำนวนเงิน: ฿${parseFloat(requestData.amount).toLocaleString('th-TH')}
หมายเหตุ: ${requestData.note || '-'}

รายการวัสดุ:
${requestData.material_list.map(item => `- ${item.item}: ${item.quantity}`).join('\n')}

ลิงก์การดำเนินการ:
อนุมัติ: ${approveUrl}
ไม่อนุมัติ: ${rejectUrl}

---
อีเมลนี้ถูกส่งจากระบบ Stock Scribe Analyzer
    `;

    // Validate email addresses
    const { valid: validCC, invalid: invalidCC } = emailService.validateEmails(ccEmails);
    if (invalidCC.length > 0) {
      console.warn('Invalid CC emails:', invalidCC);
    }

    // Prepare email data
    const emailData: EmailData = {
      to: approverEmail,
      cc: validCC,
      subject: `คำขออนุมัติใช้งบประมาณ - ${requestData.requester} (${requestId})`,
      htmlBody,
      textBody
    };


    console.log('Sending email via Postfix + Dovecot:', {
      to: emailData.to,
      cc: emailData.cc,
      subject: emailData.subject
    });

    try {
      const result = await emailService.sendEmail(emailData);
      
      if (!result.success) {
        throw new Error(result.error || 'ไม่สามารถส่งอีเมลได้');
      }
      
      console.log('Email sent successfully via Postfix:', result.message);
      return result;
      
    } catch (error) {
      console.error('Postfix email sending error:', error);
      throw new Error(`เกิดข้อผิดพลาดในการส่งอีเมล: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };


  return (
    <div className="space-y-6">
      <form onSubmit={handleBudgetSubmit} className="space-y-6">
        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="requester">ชื่อผู้ขอ *</Label>
            <Select
              value={formData.requester}
              onValueChange={(value) => { if (value !== '__loading__' && value !== '__empty__') handleInputChange('requester', value); }}
            >
              <SelectTrigger>
                <SelectValue placeholder={isLoadingRequesters ? "กำลังโหลด..." : "เลือกผู้ขอ"} />
              </SelectTrigger>
              <SelectContent>
                {isLoadingRequesters ? (
                  <SelectItem value="__loading__" disabled>กำลังโหลดรายชื่อผู้ขอ...</SelectItem>
                ) : requesters.length === 0 ? (
                  <SelectItem value="__empty__" disabled>ไม่พบรายชื่อผู้ขอ</SelectItem>
                ) : (
                  requesters.map((requester) => (
                    <SelectItem key={requester.id} value={requester.name}>
                      {requester.name} ({requester.department || 'ไม่ระบุแผนก'})
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="request_date">วันที่ *</Label>
            <Input
              id="request_date"
              type="date"
              value={formData.request_date}
              onChange={(e) => handleInputChange('request_date', e.target.value)}
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="account_code">รหัสบัญชี *</Label>
            <Select
              value={formData.account_code}
              onValueChange={(value) => handleInputChange('account_code', value)}
              required
              disabled={isLoadingAccountCodes}
            >
              <SelectTrigger>
                <SelectValue placeholder={isLoadingAccountCodes ? "กำลังโหลด..." : "เลือกรหัสบัญชี"} />
              </SelectTrigger>
              <SelectContent>
                {console.log('🎯 Rendering account codes:', accountCodes.length, 'items')}
                {isLoadingAccountCodes ? (
                  <SelectItem value="loading" disabled>
                    กำลังโหลดข้อมูล...
                  </SelectItem>
                ) : accountCodes.length > 0 ? (
                  accountCodes.map((account) => (
                    <SelectItem key={account.id} value={account.code}>
                      {account.code} - {account.name}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="no-data" disabled>
                    ไม่มีข้อมูลรหัสบัญชี
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="amount">จำนวนเงิน (บาท) *</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="0"
              value={formData.amount}
              onChange={(e) => handleInputChange('amount', e.target.value)}
              placeholder="0.00"
              required
            />
          </div>
        </div>

        {/* Material List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-lg font-semibold">รายการวัสดุ</Label>
            <Button type="button" variant="outline" size="sm" onClick={addMaterialItem}>
              <Plus className="h-4 w-4 mr-2" />
              เพิ่มรายการ
            </Button>
          </div>
          
          <div className="space-y-3">
            {formData.material_list.map((item, index) => (
              <div key={index} className="flex gap-3 items-end">
                <div className="flex-1">
                  <Label htmlFor={`item-${index}`}>รายการ</Label>
                  <Input
                    id={`item-${index}`}
                    value={item.item}
                    onChange={(e) => handleMaterialChange(index, 'item', e.target.value)}
                    placeholder="ระบุรายการวัสดุ"
                  />
                </div>
                <div className="w-32">
                  <Label htmlFor={`quantity-${index}`}>จำนวน</Label>
                  <Input
                    id={`quantity-${index}`}
                    value={item.quantity}
                    onChange={(e) => handleMaterialChange(index, 'quantity', e.target.value)}
                    placeholder="จำนวน"
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeMaterialItem(index)}
                  disabled={formData.material_list.length === 1}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="space-y-2">
          <Label htmlFor="note">หมายเหตุ</Label>
          <Textarea
            id="note"
            value={formData.note}
            onChange={(e) => handleInputChange('note', e.target.value)}
            placeholder="ระบุหมายเหตุเพิ่มเติม (ไม่บังคับ)"
            rows={3}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <Button 
            type="button" 
            variant="outline" 
            size="lg"
            onClick={() => {
              // Clear form and close modal
              setFormData({
                requester: '',
                request_date: new Date().toISOString().split('T')[0],
                account_code: '',
                amount: '',
                note: '',
                material_list: []
              });
              // Close modal
              onSuccess();
            }}
            disabled={isSubmitting}
            className="px-8"
          >
            ยกเลิก
          </Button>
          <Button type="submit" size="lg" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                กำลังดำเนินการ...
              </>
            ) : (
              <>
                <Send className="h-5 w-5 mr-2" />
                {editRequest ? 'บันทึกการแก้ไข' : 'ส่งคำขออนุมัติ'}
              </>
            )}
          </Button>
        </div>
      </form>

      {/* Email Preview Modal */}
      <Dialog open={isEmailModalOpen} onOpenChange={setIsEmailModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              ตัวอย่างอีเมลที่จะส่งไปยังผู้อนุมัติ
            </DialogTitle>
            <DialogDescription>
              ตรวจสอบเนื้อหาอีเมลก่อนส่งไปยังผู้อนุมัติ
            </DialogDescription>
            <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </DialogClose>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Email Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">ข้อมูลผู้อนุมัติ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="approver_select">ชื่อผู้อนุมัติ *</Label>
                    <Select onValueChange={(value) => {
                      const selectedApprover = approvers.find(a => a.id === value);
                      if (selectedApprover) {
                        setEmailPreviewData(prev => ({
                          ...prev,
                          approverName: selectedApprover.name,
                          approverEmail: selectedApprover.email
                        }));
                      }
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder={
                          isLoadingApprovers 
                            ? "กำลังโหลด..." 
                            : approvers.length === 0 
                            ? "ไม่มีข้อมูลผู้อนุมัติ" 
                            : "เลือกผู้อนุมัติ"
                        } />
                      </SelectTrigger>
                      <SelectContent>
                        {isLoadingApprovers ? (
                          <SelectItem value="__loading__" disabled>กำลังโหลด...</SelectItem>
                        ) : approvers.length === 0 ? (
                          <SelectItem value="__empty__" disabled>ไม่มีข้อมูลผู้อนุมัติ</SelectItem>
                        ) : (
                          approvers.map((approver) => (
                            <SelectItem key={approver.id} value={approver.id}>
                              {approver.name} ({approver.department})
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="selected_approver_email">อีเมลผู้อนุมัติที่เลือก</Label>
                    <Input
                      id="selected_approver_email"
                      type="email"
                      value={emailPreviewData.approverEmail}
                      readOnly
                      placeholder="กรุณาเลือกผู้อนุมัติก่อน"
                      className="bg-gray-50"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cc_emails">CC (ไม่บังคับ)</Label>
                  <Input
                    id="cc_emails"
                    value={emailPreviewData.ccEmails}
                    onChange={(e) => setEmailPreviewData(prev => ({ ...prev, ccEmails: e.target.value }))}
                    placeholder="email1@example.com, email2@example.com"
                  />
                  <p className="text-sm text-muted-foreground">
                    คั่นด้วยเครื่องหมายจุลภาค (,) หากมีหลายอีเมล
                  </p>
                </div>
                
                <div className="pt-2 space-y-2">
                  {/* Email configuration fields */}
                </div>
              </CardContent>
            </Card>

            {/* Email Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">ตัวอย่างอีเมล</CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="border rounded-lg p-4 bg-muted/30 min-h-[200px]"
                  dangerouslySetInnerHTML={{ __html: generateEmailPreview() }}
                />
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => setIsEmailModalOpen(false)}
                disabled={isSendingEmail}
              >
                ยกเลิก
              </Button>
              <Button onClick={sendBudgetRequest} disabled={isSendingEmail}>
                {isSendingEmail ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    กำลังส่ง...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    ส่งอีเมลและบันทึก
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Debug Component */}
      <AccountCodesDebug 
        accountCodes={accountCodes}
        isLoading={isLoadingAccountCodes}
        error={null}
      />
    </div>
  );
}