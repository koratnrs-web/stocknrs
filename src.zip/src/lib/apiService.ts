// Dynamic API base URL that works for both local and external access
const getApiBaseUrl = () => {
  // If running in browser, use current hostname
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol;
    const hostname = window.location.hostname;
    // Use backend port directly for separated frontend/backend
    return `${protocol}//${hostname}:3001/api`;
  }
  // Fallback for server-side rendering
  return 'http://localhost:3001/api';
};

const API_BASE_URL = getApiBaseUrl();

// Enhanced error handling and logging
const handleApiResponse = async (response: Response, endpoint: string) => {
  const contentType = response.headers.get('content-type');
  
  if (!response.ok) {
    let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
    
    try {
      if (contentType && contentType.includes('application/json')) {
        const errorData = await response.json();
        errorMessage = errorData.error || errorData.message || errorMessage;
      } else {
        const textError = await response.text();
        console.error(`API Error Response (${endpoint}):`, textError);
        errorMessage = `Server error: ${textError.substring(0, 200)}`;
      }
    } catch (parseError) {
      console.error(`Failed to parse error response from ${endpoint}:`, parseError);
    }
    
    console.error(`❌ API Error (${endpoint}):`, {
      status: response.status,
      statusText: response.statusText,
      url: response.url,
      contentType,
      error: errorMessage
    });
    
    throw new Error(errorMessage);
  }
  
  if (contentType && contentType.includes('application/json')) {
    return await response.json();
  } else {
    const text = await response.text();
    console.warn(`⚠️ Non-JSON response from ${endpoint}:`, text.substring(0, 200));
    throw new Error(`Expected JSON response, got: ${contentType}`);
  }
};

// Authentication state
let authToken: string | null = null;

// Authentication methods
export const auth = {
  async login(username: string, password: string) {
    try {
      console.log(`🔐 Attempting login for user: ${username}`);
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await handleApiResponse(response, 'login');
      authToken = data.token;
      localStorage.setItem('authToken', data.token);
      console.log(`✅ Login successful for user: ${username}`);
      return data;
    } catch (error) {
      console.error('❌ Login error:', error);
      throw error;
    }
  },

  logout() {
    authToken = null;
    localStorage.removeItem('authToken');
  },

  getToken() {
    if (!authToken) {
      authToken = localStorage.getItem('authToken');
    }
    return authToken;
  },

  isAuthenticated() {
    return !!this.getToken();
  }
};

// Initialize token from localStorage
authToken = localStorage.getItem('authToken');

// Types
export type AccountCode = {
  id: string;
  code: string;
  name: string;
  description?: string;
  created_at: string;
  updated_at: string;
};

export type Category = {
  id: string;
  name: string;
  description?: string;
  created_at: string;
  updated_at: string;
};

export type Supplier = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  contact_person?: string;
  created_at: string;
  updated_at: string;
};

export type Product = {
  id: string;
  name: string;
  sku: string;
  description?: string;
  category_id: string;
  supplier_id: string;
  unit_price: number;
  current_stock: number;
  min_stock: number;
  max_stock?: number;
  unit?: string;
  location?: string;
  barcode?: string;
  category_name?: string;
  supplier_name?: string;
  created_at: string;
  updated_at: string;
};

export type Movement = {
  id: string;
  product_id: string;
  type: 'in' | 'out';
  quantity: number;
  reason: string;
  reference?: string;
  notes?: string;
  product_name?: string;
  sku?: string;
  created_at: string;
  updated_at: string;
};

export type BudgetRequest = {
  id: string;
  request_no: string;
  requester_name: string;
  department: string;
  purpose: string;
  amount: number;
  account_code_id: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
};

export type Approval = {
  id: string;
  request_id: string;
  approver_name: string;
  approval_date: string;
  comments?: string;
  created_at: string;
};

export type Setting = {
  id: string;
  key: string;
  value: string;
  category: string;
  created_at: string;
  updated_at: string;
};

export type Requester = {
  id: string;
  name: string;
  email: string;
  department?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type Approver = {
  id: string;
  name: string;
  email: string;
  department?: string;
  position?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

// API Service Class
export class ApiService {
  // Generic fetch wrapper
  private static async fetchApi(endpoint: string, options: RequestInit = {}) {
    try {
      const token = auth.getToken();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      // Merge custom headers properly
      if (options.headers) {
        Object.assign(headers, options.headers);
      }

      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      });

      return await handleApiResponse(response, endpoint);
    } catch (error) {
      console.error(`❌ API Error (${endpoint}):`, error);
      throw error;
    }
  }

  // Account Codes
  static async getAccountCodes(): Promise<AccountCode[]> {
    return this.fetchApi('/account-codes');
  }

  static async createAccountCode(accountCode: Omit<AccountCode, 'id' | 'created_at' | 'updated_at'>): Promise<AccountCode> {
    return this.fetchApi('/account-codes', {
      method: 'POST',
      body: JSON.stringify(accountCode),
    });
  }

  static async updateAccountCode(id: string, accountCode: Partial<AccountCode>): Promise<AccountCode> {
    return this.fetchApi(`/account-codes/${id}`, {
      method: 'PUT',
      body: JSON.stringify(accountCode),
    });
  }

  static async deleteAccountCode(id: string): Promise<void> {
    return this.fetchApi(`/account-codes/${id}`, {
      method: 'DELETE',
    });
  }

  // Categories
  static async getCategories(): Promise<Category[]> {
    return this.fetchApi('/categories');
  }

  static async createCategory(category: Omit<Category, 'id' | 'created_at' | 'updated_at'>): Promise<Category> {
    return this.fetchApi('/categories', {
      method: 'POST',
      body: JSON.stringify(category),
    });
  }

  static async updateCategory(id: string, category: Partial<Category>): Promise<Category> {
    return this.fetchApi(`/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(category),
    });
  }

  static async deleteCategory(id: string): Promise<void> {
    return this.fetchApi(`/categories/${id}`, {
      method: 'DELETE',
    });
  }

  // Suppliers
  static async getSuppliers(): Promise<Supplier[]> {
    return this.fetchApi('/suppliers');
  }

  static async createSupplier(supplier: Omit<Supplier, 'id' | 'created_at' | 'updated_at'>): Promise<Supplier> {
    return this.fetchApi('/suppliers', {
      method: 'POST',
      body: JSON.stringify(supplier),
    });
  }

  static async updateSupplier(id: string, supplier: Partial<Supplier>): Promise<Supplier> {
    return this.fetchApi(`/suppliers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(supplier),
    });
  }

  static async deleteSupplier(id: string): Promise<void> {
    return this.fetchApi(`/suppliers/${id}`, {
      method: 'DELETE',
    });
  }

  // Products
  static async getProducts(): Promise<Product[]> {
    return this.fetchApi('/products');
  }

  static async getProductById(id: string): Promise<Product> {
    return this.fetchApi(`/products/${id}`);
  }

  static async getProductByBarcode(barcode: string): Promise<Product | null> {
    const products = await this.getProducts();
    return products.find(p => p.barcode === barcode) || null;
  }

  static async createProduct(product: Omit<Product, 'id' | 'created_at' | 'updated_at'>): Promise<Product> {
    return this.fetchApi('/products', {
      method: 'POST',
      body: JSON.stringify(product),
    });
  }

  static async updateProduct(id: string, product: Partial<Product>): Promise<Product> {
    return this.fetchApi(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(product),
    });
  }

  static async deleteProduct(id: string): Promise<void> {
    return this.fetchApi(`/products/${id}`, {
      method: 'DELETE',
    });
  }

  // Movements
  static async getMovements(): Promise<Movement[]> {
    return this.fetchApi('/movements');
  }

  static async createMovement(movement: Omit<Movement, 'id' | 'created_at' | 'updated_at'>): Promise<Movement> {
    return this.fetchApi('/movements', {
      method: 'POST',
      body: JSON.stringify(movement),
    });
  }

  // Budget Requests
  static async getBudgetRequests(): Promise<BudgetRequest[]> {
    return this.fetchApi('/budget-requests');
  }

  static async getBudgetRequestById(id: string): Promise<BudgetRequest> {
    return this.fetchApi(`/budget-requests/${id}`);
  }

  static async createBudgetRequest(request: Omit<BudgetRequest, 'id' | 'created_at' | 'updated_at'>): Promise<BudgetRequest> {
    return this.fetchApi('/budget-requests', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  static async updateBudgetRequest(id: string, request: Partial<BudgetRequest>): Promise<BudgetRequest> {
    return this.fetchApi(`/budget-requests/${id}`, {
      method: 'PUT',
      body: JSON.stringify(request),
    });
  }

  static async deleteBudgetRequest(id: string): Promise<void> {
    return this.fetchApi(`/budget-requests/${id}`, {
      method: 'DELETE',
    });
  }

  // Approvals
  static async getApprovalByRequestId(requestId: string): Promise<Approval | null> {
    const approvals = await this.fetchApi('/approvals');
    return approvals.find(a => a.request_id === requestId) || null;
  }

  static async createApproval(approval: Omit<Approval, 'id' | 'created_at'>): Promise<Approval> {
    return this.fetchApi('/approvals', {
      method: 'POST',
      body: JSON.stringify(approval),
    });
  }

  // Statistics
  static async getStats(): Promise<{
    totalProducts: number;
    totalValue: number;
    lowStockItems: number;
    outOfStockItems: number;
    recentMovements: number;
  }> {
    return this.fetchApi('/stats');
  }

  // Search
  static async searchProducts(query: string): Promise<Product[]> {
    const products = await this.getProducts();
    const searchTerm = query.toLowerCase();
    return products.filter(product => 
      product.name.toLowerCase().includes(searchTerm) ||
      product.sku.toLowerCase().includes(searchTerm) ||
      (product.barcode && product.barcode.toLowerCase().includes(searchTerm))
    );
  }

  // Health check
  static async healthCheck(): Promise<{ status: string; timestamp: string; database: string }> {
    return this.fetchApi('/health');
  }

  // Settings
  static async getSettings(): Promise<Setting[]> {
    return this.fetchApi('/settings');
  }

  static async updateSetting(key: string, setting: Partial<Setting>): Promise<Setting> {
    return this.fetchApi(`/settings/${key}`, {
      method: 'PUT',
      body: JSON.stringify(setting),
    });
  }

  // Requesters
  static async getRequesters(): Promise<Requester[]> {
    return this.fetchApi('/requesters');
  }

  static async createRequester(requester: Omit<Requester, 'id' | 'created_at' | 'updated_at'>): Promise<Requester> {
    return this.fetchApi('/requesters', {
      method: 'POST',
      body: JSON.stringify(requester),
    });
  }

  static async deactivateAllRequesters(): Promise<void> {
    return this.fetchApi('/requesters/deactivate-all', {
      method: 'PUT',
    });
  }

  // Bulk delete operations

  // Approvers
  static async getApprovers(): Promise<Approver[]> {
    return this.fetchApi('/approvers');
  }

  static async createApprover(approver: Omit<Approver, 'id' | 'created_at' | 'updated_at'>): Promise<Approver> {
    return this.fetchApi('/approvers', {
      method: 'POST',
      body: JSON.stringify(approver),
    });
  }

  static async deleteAllMovements(): Promise<void> {
    return this.fetchApi('/movements/delete-all', {
      method: 'DELETE',
    });
  }

  static async deleteAllProducts(): Promise<void> {
    return this.fetchApi('/products/delete-all', {
      method: 'DELETE',
    });
  }

  static async deleteAllCategories(): Promise<void> {
    return this.fetchApi('/categories/delete-all', {
      method: 'DELETE',
    });
  }

  static async deleteAllSuppliers(): Promise<void> {
    return this.fetchApi('/suppliers/delete-all', {
      method: 'DELETE',
    });
  }
}

// Export instance
export const api = ApiService;
