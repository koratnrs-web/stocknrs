const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Types (รีใช้จาก database.ts)
export type {
  AccountCode,
  Category,
  Supplier,
  Product,
  Movement,
  BudgetRequest,
  Approval
} from './database';

class ApiClient {
  private baseURL: string;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseURL}${endpoint}`;
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
      }

      // Handle 204 No Content responses
      if (response.status === 204) {
        return null as T;
      }

      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('text/html')) {
        throw new Error(`Server returned HTML instead of JSON. Backend may not be running.`);
      }

      return await response.json();
    } catch (error) {
      console.error(`API request failed: ${endpoint}`, error);
      throw error;
    }
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }

  // System status
  async getSystemStatus() {
    return this.request('/status');
  }

  // Backup System
  async createBackup() {
    return this.request('/backup/create', {
      method: 'POST',
    });
  }

  async restoreBackup(backupData: any) {
    return this.request('/backup/restore', {
      method: 'POST',
      body: JSON.stringify({ backupData }),
    });
  }

  async getAutoBackupStatus() {
    return this.request('/backup/auto-status');
  }

  // Email System
  async testEmailConnection() {
    return this.request('/email/test', {
      method: 'POST',
    });
  }

  async sendLowStockAlert() {
    return this.request('/email/low-stock-alert', {
      method: 'POST',
    });
  }

  async sendBudgetApprovalEmail(budgetRequestId: string, approverEmail: string, ccEmails?: string[]) {
    return this.request('/email/budget-approval', {
      method: 'POST',
      body: JSON.stringify({ budgetRequestId, approverEmail, ccEmails }),
    });
  }

  async getEmailStatus() {
    return this.request('/email/status');
  }

  // Settings
  async getSettings() {
    return this.request('/settings');
  }

  async updateSettings(payload: {
    company_name: string;
    email: string;
    phone: string;
    address: string;
    low_stock_alert: boolean;
    email_notifications: boolean;
    auto_backup: boolean;
    theme: 'light' | 'dark' | 'system';
    language: 'en' | 'th';
    currency: 'THB' | 'USD' | 'EUR';
    smtp_host?: string;
    smtp_port?: number;
    smtp_secure?: boolean;
    smtp_user?: string;
    smtp_password?: string;
    from_email?: string;
    from_name?: string;
  }) {
    return this.request('/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  }

  // Categories
  async getCategories() {
    return this.request('/categories');
  }

  async createCategory(category: { name: string; description: string; is_medicine?: boolean }) {
    return this.request('/categories', {
      method: 'POST',
      body: JSON.stringify(category),
    });
  }

  async updateCategory(id: string, category: Partial<{ name: string; description: string; is_medicine: boolean }>) {
    return this.request(`/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(category),
    });
  }

  async deleteCategory(id: string) {
    return this.request(`/categories/${id}`, {
      method: 'DELETE',
    });
  }

  // Suppliers
  async getSuppliers() {
    return this.request('/suppliers');
  }

  async createSupplier(supplier: { name: string; email: string; phone: string; address: string }) {
    return this.request('/suppliers', {
      method: 'POST',
      body: JSON.stringify(supplier),
    });
  }

  async updateSupplier(id: string, supplier: Partial<{ name: string; email: string; phone: string; address: string }>) {
    return this.request(`/suppliers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(supplier),
    });
  }

  async deleteSupplier(id: string) {
    return this.request(`/suppliers/${id}`, {
      method: 'DELETE',
    });
  }

  // Products
  async getProducts() {
    return this.request('/products');
  }

  async getProduct(id: string) {
    return this.request(`/products/${id}`);
  }

  async createProduct(product: {
    name: string;
    sku: string;
    description?: string;
    category_id: string;
    supplier_id: string;
    unit_price: number;
    current_stock: number;
    min_stock: number;
    max_stock?: number;
    unit?: string;
    location?: string;
    barcode?: string;
    expiry_date?: string;
  }) {
    return this.request('/products', {
      method: 'POST',
      body: JSON.stringify(product),
    });
  }

  async updateProduct(id: string, product: Partial<{
    name: string;
    sku: string;
    description: string;
    category_id: string;
    supplier_id: string;
    unit_price: number;
    current_stock: number;
    min_stock: number;
    max_stock: number;
    unit: string;
    location: string;
    barcode: string;
    expiry_date: string;
  }>) {
    return this.request(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(product),
    });
  }

  async deleteProduct(id: string) {
    return this.request(`/products/${id}`, {
      method: 'DELETE',
    });
  }

  // Movements
  async getMovements() {
    return this.request('/movements');
  }

  async createMovement(movement: {
    product_id: string;
    type: 'in' | 'out';
    quantity: number;
    reason: string;
    reference?: string;
    notes?: string;
    created_by?: string;
  }) {
    return this.request('/movements', {
      method: 'POST',
      body: JSON.stringify(movement),
    });
  }

  // Account Codes
  async getAccountCodes() {
    return this.request('/account-codes');
  }

  // Budget Requests
  async getBudgetRequests() {
    return this.request('/budget-requests');
  }

  async createBudgetRequest(request: {
    request_no: string;
    requester: string;
    request_date: string;
    account_code: string;
    account_name?: string;
    amount: number;
    note?: string;
    material_list: Array<{ item: string; quantity: string }>;
    status?: 'PENDING' | 'APPROVED' | 'REJECTED';
  }) {
    return this.request('/budget-requests', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async deleteBudgetRequest(id: string | number) {
    return this.request(`/budget-requests/${id}`, {
      method: 'DELETE',
    });
  }

  async updateBudgetRequestStatus(id: number, status: string) {
    return this.request(`/budget-requests/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  // Approvals
  async getApprovals() {
    return this.request('/approvals');
  }

  async createApproval(approval: {
    request_id: string;
    decision: string;
    remark?: string;
    approver_name: string;
  }) {
    return this.request('/approvals', {
      method: 'POST',
      body: JSON.stringify(approval),
    });
  }

  // Users
  async getUsers() {
    return this.request('/users');
  }

  // Password reset
  async requestPasswordReset(usernameOrEmail: string) {
    return this.request('/auth/password-reset/request', {
      method: 'POST',
      body: JSON.stringify({ usernameOrEmail }),
    });
  }

  async confirmPasswordReset(token: string, newPassword: string) {
    return this.request('/auth/password-reset/confirm', {
      method: 'POST',
      body: JSON.stringify({ token, newPassword }),
    });
  }

  async login(username: string, password: string) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    return this.request('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ userId, currentPassword, newPassword }),
    });
  }

  async createUser(user: {
    username: string;
    email?: string;
    password: string;
    role?: 'admin' | 'manager' | 'user';
    is_active?: boolean;
  }) {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify(user),
    });
  }

  async updateUser(id: string, updates: Partial<{ 
    username: string; email: string; password: string; role: 'admin' | 'manager' | 'user'; is_active: boolean; 
  }>) {
    return this.request(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async deleteUser(id: string) {
    return this.request(`/users/${id}`, {
      method: 'DELETE',
    });
  }
}

// Create and export API client instance
export const apiClient = new ApiClient(API_BASE_URL);
